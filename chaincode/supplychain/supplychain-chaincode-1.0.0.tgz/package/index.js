'use strict';

const { Contract } = require('fabric-contract-api');
const crypto = require('crypto');

class SupplyChainContract extends Contract {

  // ─── Initialize ledger with sample data ───────────────────────────────────
  async initLedger(ctx) {
    const products = [
      {
        productId:      'PROD001',
        name:           'Laptop Model X1',
        category:       'Electronics',
        currentStatus:  'MANUFACTURED',
        currentOwner:   'AcmeCorp',
        manufacturer:   'AcmeCorp',
        metadata:       { weight: '2.1kg', color: 'silver' },
        timestamp:      new Date().toISOString(),
        history:        []
      }
    ];

    for (const product of products) {
      await ctx.stub.putState(
        product.productId,
        Buffer.from(JSON.stringify(product))
      );
    }
    console.log('Ledger initialized with sample products');
  }

  // ─── Create a new product ──────────────────────────────────────────────────
  async createProduct(ctx, productId, name, category, manufacturer, metadataJson) {
    // Check product doesn't already exist
    const existing = await ctx.stub.getState(productId);
    if (existing && existing.length > 0) {
      throw new Error(`Product ${productId} already exists`);
    }

    const metadata = JSON.parse(metadataJson);
    const txId = ctx.stub.getTxID();
    const timestamp = new Date().toISOString();

    const product = {
      productId,
      name,
      category,
      currentStatus:  'MANUFACTURED',
      currentOwner:   manufacturer,
      manufacturer,
      metadata,
      fabricTxId:     txId,
      createdAt:      timestamp,
      updatedAt:      timestamp,
      history: [
        {
          status:      'MANUFACTURED',
          owner:       manufacturer,
          location:    metadata.location || 'Unknown',
          timestamp,
          txId,
          notes:       'Product created and quality checked'
        }
      ]
    };

    await ctx.stub.putState(productId, Buffer.from(JSON.stringify(product)));

    // Emit an event so the API can react
    ctx.stub.setEvent('ProductCreated', Buffer.from(JSON.stringify({
      productId, name, manufacturer, txId, timestamp
    })));

    return JSON.stringify(product);
  }

  // ─── Transfer product between stakeholders ────────────────────────────────
  async transferProduct(ctx, productId, newOwner, newStatus, location, notes) {
    const productBytes = await ctx.stub.getState(productId);
    if (!productBytes || productBytes.length === 0) {
      throw new Error(`Product ${productId} does not exist`);
    }

    const product = JSON.parse(productBytes.toString());

    // Validate the status transition
    const validTransitions = {
      'MANUFACTURED': ['SHIPPED_TO_DISTRIBUTOR'],
      'SHIPPED_TO_DISTRIBUTOR': ['RECEIVED_BY_DISTRIBUTOR'],
      'RECEIVED_BY_DISTRIBUTOR': ['SHIPPED_TO_RETAILER'],
      'SHIPPED_TO_RETAILER': ['RECEIVED_BY_RETAILER'],
      'RECEIVED_BY_RETAILER': ['SOLD_TO_CUSTOMER'],
      'SOLD_TO_CUSTOMER': []
    };

    const allowed = validTransitions[product.currentStatus];
    if (!allowed) {
      throw new Error(`Unknown current status: ${product.currentStatus}`);
    }
    if (!allowed.includes(newStatus)) {
      throw new Error(
        `Invalid transition: ${product.currentStatus} → ${newStatus}. ` +
        `Allowed: ${allowed.join(', ')}`
      );
    }

    const txId = ctx.stub.getTxID();
    const timestamp = new Date().toISOString();

    // Append to history
    product.history.push({
      status:    newStatus,
      owner:     newOwner,
      location,
      timestamp,
      txId,
      notes:     notes || ''
    });

    // Update current state
    const previousOwner   = product.currentOwner;
    const previousStatus  = product.currentStatus;
    product.currentOwner  = newOwner;
    product.currentStatus = newStatus;
    product.fabricTxId    = txId;
    product.updatedAt     = timestamp;

    await ctx.stub.putState(productId, Buffer.from(JSON.stringify(product)));

    // Emit transfer event
    ctx.stub.setEvent('ProductTransferred', Buffer.from(JSON.stringify({
      productId, previousOwner, newOwner,
      previousStatus, newStatus, location, txId, timestamp
    })));

    return JSON.stringify(product);
  }

  // ─── Query a single product ────────────────────────────────────────────────
  async queryProduct(ctx, productId) {
    const productBytes = await ctx.stub.getState(productId);
    if (!productBytes || productBytes.length === 0) {
      throw new Error(`Product ${productId} does not exist`);
    }
    return productBytes.toString();
  }

  // ─── Get full blockchain history for a product ────────────────────────────
  async getProductHistory(ctx, productId) {
    const iterator = await ctx.stub.getHistoryForKey(productId);
    const history  = [];

    while (true) {
      const result = await iterator.next();
      if (result.done) break;

      const record = {
        txId:      result.value.txId,
        timestamp: new Date(
          result.value.timestamp.seconds.low * 1000
        ).toISOString(),
        isDelete:  result.value.isDelete,
        value:     result.value.value
          ? JSON.parse(result.value.value.toString())
          : null
      };
      history.push(record);
    }

    await iterator.close();
    return JSON.stringify(history);
  }

  // ─── Query all products (for admin dashboard) ─────────────────────────────
  async queryAllProducts(ctx) {
    const iterator = await ctx.stub.getStateByRange('', '');
    const products = [];

    while (true) {
      const result = await iterator.next();
      if (result.done) break;

      if (result.value && result.value.value) {
        try {
          products.push(JSON.parse(result.value.value.toString()));
        } catch (e) {
          // skip malformed records
        }
      }
    }

    await iterator.close();
    return JSON.stringify(products);
  }

  // ─── Verify data integrity (compare hash against Cassandra record) ─────────
  async verifyProduct(ctx, productId, expectedHash) {
    const productBytes = await ctx.stub.getState(productId);
    if (!productBytes || productBytes.length === 0) {
      throw new Error(`Product ${productId} does not exist`);
    }

    const actualHash = crypto
      .createHash('sha256')
      .update(productBytes)
      .digest('hex');

    const verified = actualHash === expectedHash;

    return JSON.stringify({
      productId,
      verified,
      actualHash,
      expectedHash,
      timestamp: new Date().toISOString()
    });
  }
}

module.exports = SupplyChainContract;
